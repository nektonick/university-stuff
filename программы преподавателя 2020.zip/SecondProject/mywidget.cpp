#include "mywidget.h"
#include "ui_mywidget.h"

MyWidget::MyWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyWidget)
{
    ui->setupUi(this);

    ui->plus->setChecked(true);
}

MyWidget::~MyWidget()
{
    delete ui;
}

void MyWidget::on_plus_toggled(bool checked)
{
    if(checked)
    {
        ui->labelOperand1->setText("Slagaemoe 1");
        ui->labelOperand2->setText("Slagaemoe 2");
        ui->labelResult->setText("Summa");
    }
}

void MyWidget::on_calc_clicked()
{
    QString op1 = ui->operand1->text();
    QString op2 = ui->operand2->text();

    int a, b;
    bool okA, okB;

    a = op1.toInt(&okA);

    b = op2.toInt(&okB);

    if(okA && okB)
    {
        // Если в обоих опернадах числа

        int result;

        // если выбрано сложение
        if(ui->plus->isChecked())
        {
            result = a + b;
        }
        // ...

        QString resultText = QString::number(result);
        ui->result->setText(resultText);

        ui->operand1->setPalette(QPalette());

    }
    else
    {
        if(!okA && !okB)
        {
            // не число в обоих операндах

            ui->error->setText("Both operand not number");

            QPalette pal = ui->operand1->palette();
            pal.setColor(QPalette::Base, QColor::fromRgb(255, 255, 0));
            ui->operand1->setPalette(pal);


        }
        else if(!okA)
        {
            // не число в 1м операнде

            ui->error->setText("Operand1 not number");
        }
        else
        {
            // не число во 2м операнде

            ui->error->setText("Operand2 not number");
        }
    }
}
