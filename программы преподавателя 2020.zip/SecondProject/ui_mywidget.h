/********************************************************************************
** Form generated from reading UI file 'mywidget.ui'
**
** Created: Sat 5. Sep 15:36:02 2020
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MYWIDGET_H
#define UI_MYWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MyWidget
{
public:
    QVBoxLayout *verticalLayout_6;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_3;
    QLabel *labelOperand1;
    QLineEdit *operand1;
    QSpacerItem *verticalSpacer;
    QVBoxLayout *verticalLayout_2;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QRadioButton *plus;
    QRadioButton *minus;
    QRadioButton *multi;
    QRadioButton *devide;
    QPushButton *calc;
    QSpacerItem *verticalSpacer_3;
    QLabel *labelResult;
    QLineEdit *result;
    QVBoxLayout *verticalLayout_4;
    QLabel *labelOperand2;
    QLineEdit *operand2;
    QSpacerItem *verticalSpacer_2;
    QLabel *error;

    void setupUi(QWidget *MyWidget)
    {
        if (MyWidget->objectName().isEmpty())
            MyWidget->setObjectName(QString::fromUtf8("MyWidget"));
        MyWidget->resize(767, 481);
        QFont font;
        font.setPointSize(24);
        MyWidget->setFont(font);
        verticalLayout_6 = new QVBoxLayout(MyWidget);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        labelOperand1 = new QLabel(MyWidget);
        labelOperand1->setObjectName(QString::fromUtf8("labelOperand1"));

        verticalLayout_3->addWidget(labelOperand1);

        operand1 = new QLineEdit(MyWidget);
        operand1->setObjectName(QString::fromUtf8("operand1"));

        verticalLayout_3->addWidget(operand1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_3->addItem(verticalSpacer);


        horizontalLayout->addLayout(verticalLayout_3);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        groupBox = new QGroupBox(MyWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(50, -1, -1, -1);
        plus = new QRadioButton(groupBox);
        plus->setObjectName(QString::fromUtf8("plus"));
        plus->setChecked(true);

        verticalLayout->addWidget(plus);

        minus = new QRadioButton(groupBox);
        minus->setObjectName(QString::fromUtf8("minus"));

        verticalLayout->addWidget(minus);

        multi = new QRadioButton(groupBox);
        multi->setObjectName(QString::fromUtf8("multi"));

        verticalLayout->addWidget(multi);

        devide = new QRadioButton(groupBox);
        devide->setObjectName(QString::fromUtf8("devide"));

        verticalLayout->addWidget(devide);


        verticalLayout_2->addWidget(groupBox);

        calc = new QPushButton(MyWidget);
        calc->setObjectName(QString::fromUtf8("calc"));

        verticalLayout_2->addWidget(calc);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_3);

        labelResult = new QLabel(MyWidget);
        labelResult->setObjectName(QString::fromUtf8("labelResult"));
        labelResult->setFrameShape(QFrame::NoFrame);

        verticalLayout_2->addWidget(labelResult);

        result = new QLineEdit(MyWidget);
        result->setObjectName(QString::fromUtf8("result"));
        result->setReadOnly(true);

        verticalLayout_2->addWidget(result);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        labelOperand2 = new QLabel(MyWidget);
        labelOperand2->setObjectName(QString::fromUtf8("labelOperand2"));

        verticalLayout_4->addWidget(labelOperand2);

        operand2 = new QLineEdit(MyWidget);
        operand2->setObjectName(QString::fromUtf8("operand2"));

        verticalLayout_4->addWidget(operand2);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_4->addItem(verticalSpacer_2);


        horizontalLayout->addLayout(verticalLayout_4);


        verticalLayout_6->addLayout(horizontalLayout);

        error = new QLabel(MyWidget);
        error->setObjectName(QString::fromUtf8("error"));
        error->setFrameShape(QFrame::Box);

        verticalLayout_6->addWidget(error);


        retranslateUi(MyWidget);

        QMetaObject::connectSlotsByName(MyWidget);
    } // setupUi

    void retranslateUi(QWidget *MyWidget)
    {
        MyWidget->setWindowTitle(QApplication::translate("MyWidget", "MyWidget", 0, QApplication::UnicodeUTF8));
        labelOperand1->setText(QApplication::translate("MyWidget", "\320\236\320\277\320\265\321\200\320\260\320\275\320\264 1", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MyWidget", "\320\236\320\277\320\265\321\200\320\260\321\206\320\270\320\270", 0, QApplication::UnicodeUTF8));
        plus->setText(QApplication::translate("MyWidget", "+", 0, QApplication::UnicodeUTF8));
        minus->setText(QApplication::translate("MyWidget", "-", 0, QApplication::UnicodeUTF8));
        multi->setText(QApplication::translate("MyWidget", "*", 0, QApplication::UnicodeUTF8));
        devide->setText(QApplication::translate("MyWidget", "/", 0, QApplication::UnicodeUTF8));
        calc->setText(QApplication::translate("MyWidget", "=", 0, QApplication::UnicodeUTF8));
        labelResult->setText(QApplication::translate("MyWidget", "\320\240\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202", 0, QApplication::UnicodeUTF8));
        labelOperand2->setText(QApplication::translate("MyWidget", "\320\236\320\277\320\265\321\200\320\260\320\275\320\264 2", 0, QApplication::UnicodeUTF8));
        error->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MyWidget: public Ui_MyWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MYWIDGET_H
