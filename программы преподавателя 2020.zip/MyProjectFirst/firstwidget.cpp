#include "firstwidget.h"
#include "ui_firstwidget.h"
#include <QMessageBox>

FirstWidget::FirstWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FirstWidget)
{
    ui->setupUi(this);
}

FirstWidget::~FirstWidget()
{
    delete ui;
}

// Нажатие на кнопку
void FirstWidget::on_closeButton_clicked()
{
    // Получить ...
    QString text = ui->lineEdit->text();

    bool ok;
    // Преобразовать...
    int a = text.toInt(&ok);

    if(ok)
    {
        int b = a * a;
        QString result = QString::number(b, 16);
        // result.setNum(b);
        ui->labelResult->setText(result);
        ui->labelError->clear();
    }
    else
    {
        ui->labelError->setText("Error");
        ui->labelResult->clear();

        QMessageBox::information(this,
                                 "Error",
                                 "Not number");
    }
}
