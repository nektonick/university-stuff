#include <QtGui/QApplication>
#include "firstwidget.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    FirstWidget w;
    w.show();

    return a.exec();
}
