/********************************************************************************
** Form generated from reading UI file 'firstwidget.ui'
**
** Created: Sat 5. Sep 14:26:03 2020
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FIRSTWIDGET_H
#define UI_FIRSTWIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FirstWidget
{
public:
    QPushButton *closeButton;
    QLineEdit *lineEdit;
    QLabel *labelResult;
    QLabel *labelError;

    void setupUi(QWidget *FirstWidget)
    {
        if (FirstWidget->objectName().isEmpty())
            FirstWidget->setObjectName(QString::fromUtf8("FirstWidget"));
        FirstWidget->resize(696, 449);
        QFont font;
        font.setPointSize(24);
        FirstWidget->setFont(font);
        closeButton = new QPushButton(FirstWidget);
        closeButton->setObjectName(QString::fromUtf8("closeButton"));
        closeButton->setGeometry(QRect(160, 170, 331, 81));
        lineEdit = new QLineEdit(FirstWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(60, 60, 411, 81));
        labelResult = new QLabel(FirstWidget);
        labelResult->setObjectName(QString::fromUtf8("labelResult"));
        labelResult->setGeometry(QRect(190, 270, 201, 91));
        labelResult->setFrameShape(QFrame::Box);
        labelError = new QLabel(FirstWidget);
        labelError->setObjectName(QString::fromUtf8("labelError"));
        labelError->setGeometry(QRect(10, 400, 661, 31));
        labelError->setFrameShape(QFrame::Box);

        retranslateUi(FirstWidget);

        QMetaObject::connectSlotsByName(FirstWidget);
    } // setupUi

    void retranslateUi(QWidget *FirstWidget)
    {
        FirstWidget->setWindowTitle(QApplication::translate("FirstWidget", "\320\234\320\276\321\217 \320\277\320\265\321\200\320\262\320\260\321\217 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\320\260", 0, QApplication::UnicodeUTF8));
        closeButton->setText(QApplication::translate("FirstWidget", "V * V", 0, QApplication::UnicodeUTF8));
        lineEdit->setText(QString());
        labelResult->setText(QString());
        labelError->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class FirstWidget: public Ui_FirstWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FIRSTWIDGET_H
