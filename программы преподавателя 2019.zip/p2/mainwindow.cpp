#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextCodec>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    //У ВАС вместо UTF-8 надо писать Windows-1251  !!!
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForLocale(QTextCodec::codecForName("UTF-8"));
    QTextCodec::setCodecForTr(QTextCodec::codecForName("UTF-8"));
    ui->setupUi(this);
    ui->labelError->setVisible(false);
    ui->labelRes->setVisible(false);
    ui->radioButtonSum->click();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_radioButtonSum_clicked()
{
    ui->labelOP1->setText("Слагаемое 1");
    ui->labelOP2->setText("Слагаемое 2");
    ui->pushButton->setText("Сумма");
}

void MainWindow::on_pushButton_clicked()
{
    bool flag; //Признак успешной конвертации
    int op1,op2; //Операнды 1 и 2
    int res; //Результат
    QString tmpstring; //Строка для конвертации
    if (ui->radioButtonSum->isChecked())//Сложение
    {
        tmpstring.clear();
        tmpstring.append(ui->lineEditOP1->text());
        op1=tmpstring.toInt(&flag);
        if (flag)
        {//Операнд 1 корректен
            tmpstring.clear();
            tmpstring.append(ui->lineEditOP2->text());
            op2=tmpstring.toInt(&flag);
            if (flag)
            {//Операнд 2 корректен
                ui->labelError->setVisible(false);
                res=op1+op2;
                ui->labelRes->setNum(res);
                ui->labelRes->setVisible(true);
            }
            else
            {//Операнд 2 не корректен
                ui->labelError->setText("Ошибка в слагаемом 2");
                ui->labelError->setVisible(true);
                ui->labelRes->setVisible(false);
            }
        }
        else
        {//Операнд 1 не корректен
            ui->labelError->setText("Ошибка в слагаемом 1");
            ui->labelError->setVisible(true);
            ui->labelRes->setVisible(false);
        }
    }
}
