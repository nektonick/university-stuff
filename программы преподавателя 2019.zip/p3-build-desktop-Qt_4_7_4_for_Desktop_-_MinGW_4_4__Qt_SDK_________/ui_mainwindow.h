/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created: Wed 11. Sep 17:20:07 2019
**      by: Qt User Interface Compiler version 4.7.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QStatusBar>
#include <QtGui/QToolBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox;
    QRadioButton *radioButtonSum;
    QRadioButton *radioButtonSub;
    QRadioButton *radioButtonMul;
    QRadioButton *radioButtonDiv;
    QLineEdit *lineEditOP1;
    QLineEdit *lineEditOP2;
    QLabel *labelOP1;
    QLabel *labelOP2;
    QPushButton *pushButton;
    QLabel *labelRes;
    QLabel *labelError;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(732, 364);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(350, 40, 161, 131));
        radioButtonSum = new QRadioButton(groupBox);
        radioButtonSum->setObjectName(QString::fromUtf8("radioButtonSum"));
        radioButtonSum->setGeometry(QRect(10, 20, 82, 18));
        radioButtonSub = new QRadioButton(groupBox);
        radioButtonSub->setObjectName(QString::fromUtf8("radioButtonSub"));
        radioButtonSub->setGeometry(QRect(10, 40, 82, 18));
        radioButtonMul = new QRadioButton(groupBox);
        radioButtonMul->setObjectName(QString::fromUtf8("radioButtonMul"));
        radioButtonMul->setGeometry(QRect(10, 60, 82, 18));
        radioButtonDiv = new QRadioButton(groupBox);
        radioButtonDiv->setObjectName(QString::fromUtf8("radioButtonDiv"));
        radioButtonDiv->setGeometry(QRect(10, 80, 82, 18));
        lineEditOP1 = new QLineEdit(centralWidget);
        lineEditOP1->setObjectName(QString::fromUtf8("lineEditOP1"));
        lineEditOP1->setGeometry(QRect(30, 80, 113, 20));
        lineEditOP2 = new QLineEdit(centralWidget);
        lineEditOP2->setObjectName(QString::fromUtf8("lineEditOP2"));
        lineEditOP2->setGeometry(QRect(190, 80, 113, 20));
        labelOP1 = new QLabel(centralWidget);
        labelOP1->setObjectName(QString::fromUtf8("labelOP1"));
        labelOP1->setGeometry(QRect(30, 50, 71, 16));
        labelOP2 = new QLabel(centralWidget);
        labelOP2->setObjectName(QString::fromUtf8("labelOP2"));
        labelOP2->setGeometry(QRect(190, 50, 81, 16));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(530, 80, 75, 23));
        labelRes = new QLabel(centralWidget);
        labelRes->setObjectName(QString::fromUtf8("labelRes"));
        labelRes->setGeometry(QRect(640, 85, 46, 13));
        labelError = new QLabel(centralWidget);
        labelError->setObjectName(QString::fromUtf8("labelError"));
        labelError->setGeometry(QRect(40, 20, 371, 16));
        QPalette palette;
        QBrush brush(QColor(255, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(120, 120, 120, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        labelError->setPalette(palette);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 732, 20));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("MainWindow", "\320\236\320\277\320\265\321\200\320\260\321\206\320\270\320\270", 0, QApplication::UnicodeUTF8));
        radioButtonSum->setText(QApplication::translate("MainWindow", "\320\241\320\273\320\276\320\266\320\265\320\275\320\270\320\265", 0, QApplication::UnicodeUTF8));
        radioButtonSub->setText(QApplication::translate("MainWindow", "\320\222\321\213\321\207\320\270\321\202\320\260\320\275\320\270\320\265", 0, QApplication::UnicodeUTF8));
        radioButtonMul->setText(QApplication::translate("MainWindow", "\320\243\320\274\320\275\320\276\320\266\320\265\320\275\320\270\320\265", 0, QApplication::UnicodeUTF8));
        radioButtonDiv->setText(QApplication::translate("MainWindow", "\320\224\320\265\320\273\320\265\320\275\320\270\320\265", 0, QApplication::UnicodeUTF8));
        labelOP1->setText(QApplication::translate("MainWindow", "\320\236\320\277\320\265\321\200\320\260\320\275\320\264 1", 0, QApplication::UnicodeUTF8));
        labelOP2->setText(QApplication::translate("MainWindow", "\320\236\320\277\320\265\321\200\320\260\320\275\320\264 2", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("MainWindow", "\320\240\320\265\320\267\321\203\320\273\321\214\321\202\320\260\321\202", 0, QApplication::UnicodeUTF8));
        labelRes->setText(QApplication::translate("MainWindow", "\320\236\321\202\320\262\320\265\321\202", 0, QApplication::UnicodeUTF8));
        labelError->setText(QApplication::translate("MainWindow", "\320\236\321\210\320\270\320\261\320\272\320\260", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
