#include "char_editor.h"
#include "ui_char_editor.h"

char_editor::char_editor(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::char_editor)
{
    ui->setupUi(this);

    ui->name->setMaxLength(20);

    ui->force_set->setMinimum(1);
    ui->intelligence_set->setMinimum(1);
    ui->dexterity_set->setMinimum(1);
    ui->luck_set->setMinimum(1);

    ui->force_set->setMaximum(10);
    ui->intelligence_set->setMaximum(10);
    ui->dexterity_set->setMaximum(10);
    ui->luck_set->setMaximum(10);

    ui->gender_m->setChecked(true);
}


void char_editor::point_system()
{
    QString tmp = ui->points->text();
    int points = tmp.toInt();

    int strength = ui->force_set->value();
    int intelligence = ui->intelligence_set->value();
    int dexterity = ui->dexterity_set->value();
    int luck = ui->luck_set->value();

    points = 20 - (strength+intelligence+dexterity+luck);

    QString name = ui->name->text();

    bool can_create = false;

    can_create = !((!name.isEmpty()) && (name.length()>=3) && ((strength+intelligence+dexterity+luck)==20) && (strength > 3) && (intelligence >3) && (dexterity > 3) && (luck > 3));

    if((strength+intelligence+dexterity+luck)<20) ui->error->setText("Распределите очки!");
    else if(strength <= 3) ui->error->setText("Мало Силы!");
    else if(intelligence <= 3) ui->error->setText("Мало Инт.!");
    else if(dexterity <= 3) ui->error->setText("Мало Лов.!");
    else if(luck <= 3) ui->error->setText("Мало Удч.!");
    else if((strength+intelligence+dexterity+luck)>20) ui->error->setText("Много выбрано!");
    else if(name.isEmpty()) ui->error->setText("Введите имя!");
    else if(name.length()<3) ui->error->setText("Мало букв в имени");
    else ui->error->clear();

    if(strength>3) ui->force_cor->setText("✔️");
    else ui->force_cor->setText("✖️");

    if(intelligence > 3) ui->intelligence_cor->setText("✔️");
    else ui->intelligence_cor->setText("✖️");

    if(dexterity > 3) ui->dexterity_cor->setText("✔️");
    else ui->dexterity_cor->setText("✖️");

    if(luck > 3) ui->luck_cor->setText("✔️");
    else ui->luck_cor->setText("✖️");

    ui->create->setDisabled(can_create);

    ui->points->setNum(points);

    ui->health->setNum(0.8*strength + 0.2*dexterity);
    ui->mana->setNum(0.8*intelligence + 0.15*luck + 0.85*dexterity);
    ui->attack->setNum(0.5*strength + 0.2*luck + 0.3*dexterity);
    ui->defend->setNum(0.7*strength + 0.25*luck + 0.05*dexterity);

    multimap <int, string, greater<int>> characteristics = { {strength,"strength"}, {intelligence, "intelligence"}, {dexterity, "dexterity"}, {luck, "luck"} };
    multimap <int, string, greater<int>>::iterator it = characteristics.begin();

    bool flag[4];
    flag[0] = ((it++)->first != it->first);
    it = characteristics.begin();

    flag[1] = (((it++)->first == it->first));
    it = characteristics.begin();

    flag[2] = ((it++)->first == it->first) && ((it++)->first == it->first);
    it = characteristics.begin();

    flag[3] = ((it++)->first == it->first) && ((it++)->first == it->first) && ((it++)->first == it->first);
    it = characteristics.begin();

    int i = 3;
    for(;i;i--) if(flag[i]) break;
    i++;

    int score = 0;
    if(ui->gender_f->isChecked()) score +=10000;
    for(int j = 0;j<i;j++,it++)
    {
        if(it->second == "strength") score +=1000;
        if(it->second == "intelligence") score+=100;
        if(it->second == "dexterity") score+=10;
        if(it->second == "luck") score+=1;
    }

   map<int,string> class_naming =
    {
        {1,"Студент МИРЭА"}, {10001,"Студентка МИРЭА"},
        {10,"Вор"}, {10010, "Воровка"},
        {11,"Прогульщик"}, {10011,"Прогульщица"},
        {100,"Маг"}, {10100,"Ведьма"},
        {101,"Умный студент МИРЭА"},{10101,"Умная студентка МИРЭА"},
        {110,"Мошенник"},{10110,"Мошенница"},
        {111,"Удачливый мошенник"},{10111,"Удачливая мошенница"},
        {1000,"Воин"},{11000,"Воинтельница"},
        {1001,"Спортсмен МИРЭА"},{11001,"Спортсменка МИРЭА"},
        {1011,"Спортсмен-прогульщик"},{11011,"Спортсменка-прогульщица"},
        {1100,"Палладин"},{11100,"Палладин_ка"},
        {1101,"Неловкий"},{11101,"Неловкая"},
        {1110,"Невезучий"}, {11110,"Невезучая"},
        {1111,"Универсал"}, {11111,"Универсал"}
    };
    map <int, string>::iterator it_2 = class_naming.find(score);

    if(it_2!=class_naming.end()) ui->your_class->setText(QString::fromStdString(it_2->second));

}

char_editor::~char_editor()
{
    delete ui;
}

void char_editor::on_force_set_valueChanged(int)
{

    point_system();
}

void char_editor::on_dexterity_set_valueChanged(int)
{
    point_system();
}

void char_editor::on_intelligence_set_valueChanged(int)
{
    point_system();
}

void char_editor::on_luck_set_valueChanged(int)
{
    point_system();
}

void char_editor::on_name_cursorPositionChanged(int, int)
{
   point_system();
}

void char_editor::on_clear_clicked()
{
    ui->name->clear();
    ui->force_set->setValue(1);
    ui->intelligence_set->setValue(1);
    ui->dexterity_set->setValue(1);
    ui->luck_set->setValue(1);
    ui->gender_m->setChecked(true);
    point_system();
}

void char_editor::on_create_clicked()
{
    QMessageBox msgBox;
    msgBox.setText("Персонаж успешно создан.");
    msgBox.exec();
}

void char_editor::on_gender_m_clicked()
{
    point_system();
}

void char_editor::on_gender_f_clicked()
{
    point_system();
}
