#ifndef CHAR_EDITOR_H
#define CHAR_EDITOR_H

#include <QMainWindow>
#include <QMessageBox>
#include <map>
using namespace std;

namespace Ui {
class char_editor;
}

class char_editor : public QMainWindow
{
    Q_OBJECT

public:
    explicit char_editor(QWidget *parent = nullptr);
    ~char_editor();

private slots:
    void on_force_set_valueChanged(int arg1);
    void point_system();

    void on_dexterity_set_valueChanged(int arg1);

    void on_intelligence_set_valueChanged(int arg1);

    void on_luck_set_valueChanged(int arg1);

    void on_name_cursorPositionChanged(int arg1, int arg2);

    void on_clear_clicked();

    void on_create_clicked();

    void on_gender_m_clicked();

    void on_gender_f_clicked();

private:
    Ui::char_editor *ui;
};

#endif // CHAR_EDITOR_H
