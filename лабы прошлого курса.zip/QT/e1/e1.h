#ifndef E1_H
#define E1_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class e1; }
QT_END_NAMESPACE

class e1 : public QMainWindow
{
    Q_OBJECT

public:
    e1(QWidget *parent = nullptr);
    ~e1();

private slots:
    void on_input_textChanged(const QString &arg1);

private:
    Ui::e1 *ui;
};
#endif // E1_H
