#include "e1.h"
#include "ui_e1.h"
e1::e1(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::e1)
{
    ui->setupUi(this);
}

e1::~e1()
{
    delete ui;
}


void e1::on_input_textChanged(const QString &)
{
    ui->output->clear();
    QString t = ui->input->text();

    if(t.isEmpty())
    {
        ui->output->setText("Пустая строка");
    }
    else
    {
        bool flag1, flag2;
        t.toLongLong(&flag1);
        t.toDouble(&flag2);

        if(flag1)
        {
            ui->output->setText("Целое число");
        }
        else if(flag2)
        {
            ui->output->setText("Вещ.число");
        }
        else
        {
            ui->output->setText("Не число");
        }
    }


}
