/********************************************************************************
** Form generated from reading UI file 'e1.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_E1_H
#define UI_E1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_e1
{
public:
    QWidget *centralwidget;
    QLabel *output;
    QLineEdit *input;

    void setupUi(QMainWindow *e1)
    {
        if (e1->objectName().isEmpty())
            e1->setObjectName(QString::fromUtf8("e1"));
        e1->resize(132, 80);
        centralwidget = new QWidget(e1);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        output = new QLabel(centralwidget);
        output->setObjectName(QString::fromUtf8("output"));
        output->setGeometry(QRect(10, 7, 111, 31));
        output->setAlignment(Qt::AlignCenter);
        input = new QLineEdit(centralwidget);
        input->setObjectName(QString::fromUtf8("input"));
        input->setGeometry(QRect(10, 40, 113, 32));
        e1->setCentralWidget(centralwidget);

        retranslateUi(e1);

        QMetaObject::connectSlotsByName(e1);
    } // setupUi

    void retranslateUi(QMainWindow *e1)
    {
        e1->setWindowTitle(QCoreApplication::translate("e1", "e1", nullptr));
        output->setText(QCoreApplication::translate("e1", "\320\237\321\203\321\201\321\202\320\260\321\217 \321\201\321\202\321\200\320\276\320\272\320\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class e1: public Ui_e1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_E1_H
