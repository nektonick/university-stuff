#include "calc.h"
#include "ui_calc.h"

calc::calc(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::calc)
{
    ui->setupUi(this);
}

calc::~calc()
{
    delete ui;
}

void calc::on_result_button_clicked()
{
    QString text1, text2;
    text1.append(ui->input_first->text());
    text2.append(ui->input_second->text());

    double number1, number2;
    bool flag1, flag2;

    number1 = text1.toDouble(&flag1);
    number2 = text2.toDouble(&flag2);

    if(ui->op_sqrt->isChecked()) flag2 = true;


    if( !isfinite(number1) && !isfinite(number2) ) ui->result_text->setText("Числа слишком большие!");
    else if(!isfinite(number1)) ui->result_text->setText("Число 1 слишком большое!");
    else if(!isfinite(number2)) ui->result_text->setText("Число 2 слишком большое!");

    else if(flag1 && flag2)
    {
        if(ui->op_addiction->isChecked()) ui->result_text->setText(QString::number(number1+number2));
        else if(ui->op_subtraction->isChecked()) ui->result_text->setText(QString::number(number1-number2));
        else if(ui->op_multiplication->isChecked())
        {
            if(!isfinite(number1*number2))
            {
                ui->result_text->setText("Бесконечность!");
            }
            else ui->result_text->setText(QString::number(number1*number2));
        }
        else if(ui->op_division->isChecked())
        {
            if(number2 != 0.0) ui->result_text->setText(QString::number(number1/number2));
            else ui->result_text->setText("На 0 делить нельзя!");
        }
        else if(ui->op_sqrt->isChecked())
        {
            if(number1 > 0) ui->result_text->setText(QString::number(sqrt(number1)));
            else ui->result_text->setText("Число нельзя выразить!");
        }
        else ui->result_text->setText("Не выбрана операция");
    }
    else if(!(flag1 || flag2)) ui->result_text->setText("Числа не верные!");
    else if(!flag1) ui->result_text->setText("Число 1 не верно!");
    else if(!flag2) ui->result_text->setText("Число 2 не верно!");
}

void calc::on_op_addiction_clicked()
{
    ui->input_second->setDisabled(false);
}

void calc::on_op_subtraction_clicked()
{
    ui->input_second->setDisabled(false);
}

void calc::on_op_multiplication_clicked()
{
    ui->input_second->setDisabled(false);
}

void calc::on_op_division_clicked()
{
    ui->input_second->setDisabled(false);
}

void calc::on_op_sqrt_clicked()
{
    ui->input_second->setDisabled(true);
}
