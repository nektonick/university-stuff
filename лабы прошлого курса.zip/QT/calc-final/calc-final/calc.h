#ifndef CALC_H
#define CALC_H

#include <QMainWindow>

#include <math.h>
#include <cmath>

namespace Ui {
class calc;
}

class calc : public QMainWindow
{
    Q_OBJECT

public:
    explicit calc(QWidget *parent = nullptr);
    ~calc();

private slots:
    void on_result_button_clicked();

    void on_op_addiction_clicked();

    void on_op_subtraction_clicked();

    void on_op_multiplication_clicked();

    void on_op_division_clicked();

    void on_op_sqrt_clicked();

private:
    Ui::calc *ui;
};

#endif // CALC_H
