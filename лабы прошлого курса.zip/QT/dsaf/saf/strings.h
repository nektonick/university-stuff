#ifndef STRINGS_H
#define STRINGS_H

#ifdef Q_WS_WIN

#endif

#ifdef Q_X11

#endif

#endif // STRINGS_H
