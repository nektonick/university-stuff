#include <QCoreApplication>
#include <stdio.h>
#include <string.h>
#include <QTextCodec>


#ifdef Q_WS_WIN32
#define INPUT_1 "Введите два вещ.числа через пробел: "
#define ERROR_1 "Не числовое значение\n"

#define INPUT_2 "Введите строку (макс. 20 символов): "
#define INPUT_22 "Введите номер желаемой буквы: "
#define OUTPUT_2 "Буква: %c\n"
#define ERROR_2  "ОШИБКА\n"

#define INPUT_3 "Введите строку (макс. 20 символов): "
#define INPUT_33 "Введите символ: "
#define OUTPUT_3 "Номер буквы: %d\n"
#define OUTPUT_33 "\nВсего найдено: %d\n"
#define ERROR_3 "Не найдено\nДавайте попробуем еще.\n"
#endif

#ifdef Q_OS_LINUX
#define INPUT_1 "Введите два вещ.числа через пробел: "
#define ERROR_1 "Не числовое значение\n"

#define INPUT_2 "Введите строку (макс. 20 символов): "
#define INPUT_22 "Введите номер желаемой буквы: "
#define OUTPUT_2 "Буква: %c\n"
#define ERROR_2  "ОШИБКА\n"

#define INPUT_3 "Введите строку (макс. 20 символов): "
#define INPUT_33 "Введите символ: "
#define OUTPUT_3 "Номер буквы: %d\n"
#define OUTPUT_33 "\nВсего найдено: %d\n"
#define ERROR_3 "Не найдено\nДавайте попробуем еще.\n"
#endif

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //---1--------------
    while(true)
    {
        double x,y;
        printf(INPUT_1);

        int check = scanf("%lf %lf", &x, &y);
        if(check)
        {
            printf("%lf + %lf = %lf\n", x, y, x+y);
            break;
        }
        else
        {
            printf(ERROR_1);
            while ((getchar()) != '\n');
        }
    }

    //---1--------------

    while ((getchar()) != '\n');

    //---2---------------
    while(true)
    {
        char str[21] = {0};
        printf(INPUT_2);
        scanf("%20s", str);

        while ((getchar()) != '\n');

        int i, check2;
        printf(INPUT_22);
        check2  = scanf("%d", &i);

        if((check2) && (i > 0) && (i < 21))
        {
            printf(OUTPUT_2,str[i-1]);
            break;
        }
        else
        {
            printf(ERROR_2);
            while ((getchar()) != '\n');
        }
    }
    //---2----------------

    while ((getchar()) != '\n');

    //---3----------------
    while(true)
    {

        char str2[21] = {0};
        printf(INPUT_3);
        scanf("%20s", str2);

        while ((getchar()) != '\n');

        char c;
        printf(INPUT_33);
        c = fgetc(stdin);

        int found = 0;
        for(int i = 0; i < 20; i++)
        {
            if(str2[i]==c)
            {
                printf(OUTPUT_3,i+1);
                found++;
            }
            if(!str2[i]) break;
        }
        if(found)
        {
            printf(OUTPUT_33,found);
            break;
        }
        else
        {
            printf(ERROR_3);
            while ((getchar()) != '\n');
        }
    }
    //---3----------------

    return a.exec();
}
