#ifndef STRINGS_H
#define STRINGS_H

#ifdef Q_WS_WIN32
#define INPUT_1 "Введите два вещ.числа через пробел: "
#define ERROR_1 "Не числовое значение\n"

#define INPUT_2 "Введите строку (макс. 20 символов): "
#define INPUT_22 "Введите номер желаемой буквы: "
#define OUTPUT_2 "Буква: %c\n"
#define ERROR_2  "ОШИБКА\n"

#define INPUT_3 "Введите строку (макс. 20 символов): "
#define INPUT_33 "Введите символ: "
#define OUTPUT_3 "Номер буквы: %d\n"
#define OUTPUT_33 "\nВсего найдено: %d\n"
#define ERROR_3 "Не найдено\nДавайте попробуем еще.\n"
#endif

#ifdef Q_WS_X11
#define INPUT_1 "Введите два вещ.числа через пробел: "
#define ERROR_1 "Не числовое значение\n"

#define INPUT_2 "Введите строку (макс. 20 символов): "
#define INPUT_22 "Введите номер желаемой буквы: "
#define OUTPUT_2 "Буква: %c\n"
#define ERROR_2  "ОШИБКА\n"

#define INPUT_3 "Введите строку (макс. 20 символов): "
#define INPUT_33 "Введите символ: "
#define OUTPUT_3 "Номер буквы: %d\n"
#define OUTPUT_33 "\nВсего найдено: %d\n"
#define ERROR_3 "Не найдено\nДавайте попробуем еще.\n"
#endif

#endif // STRINGS_H
