#include "boolcalc.h"
#include "ui_boolcalc.h"

boolcalc::boolcalc(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::boolcalc)
{
    ui->setupUi(this);
    color_window();
}

boolcalc::~boolcalc()
{
    delete ui;
}

void boolcalc::color_window()
{
    bool o1 = ui->op1->currentIndex();
    bool o2 = ui->op2->currentIndex();
    bool result = true;

    QPalette true_pallete, false_pallete;
    true_pallete.setColor(QPalette::Window, QColor(255,69,0)); //orange
    false_pallete.setColor(QPalette::Window, QColor(128,0,128)); //violet

    ui->op1->setVisible(true);
    switch(ui->operation->currentIndex())
    {
        case 0:
            result = o1&&o2;
        break;

        case 1:
            result = o1||o2;
        break;

        case 2:          
            result = (o1||o2) && (!(o1&&o2));
        break;

        case 3:            
            result = o1^o2;
        break;

        case 4:           
            result = (o1 == o2);
        break;

        case 5:
            result = (o1 != o2);
        break;

        case 6:
            ui->op1->setVisible(false);
            result = !o2;
        break;

        case 7:
            result = ( o1 || (!o2) ) && ( (!o1) || o2 );
        break;
    }

    if(result) qApp->setPalette(true_pallete);
    else qApp->setPalette(false_pallete);
}

void boolcalc::on_operation_activated(int)
{
    color_window();
}

void boolcalc::on_op1_activated(int)
{
    color_window();
}


void boolcalc::on_op2_activated(int)
{
    color_window();
}
