#ifndef BOOLCALC_H
#define BOOLCALC_H

#include <QMainWindow>

namespace Ui {
class boolcalc;
}

class boolcalc : public QMainWindow
{
    Q_OBJECT

public:
    explicit boolcalc(QWidget *parent = nullptr);
    ~boolcalc();

private slots:
    void color_window();
    void on_operation_activated(int index);

    void on_op1_activated(int index);

    void on_op2_activated(int index);

    //void on_centralWidget_customContextMenuRequested(const QPoint &pos);

private:
    Ui::boolcalc *ui;
};

#endif // BOOLCALC_H
